import pandas as pd

df = pd.read_csv("sales_data.csv", parse_dates=["order_date"])
df["month"] = df["order_date"].dt.to_period("M").astype(str)

print("Overall KPIs")
print(f"Revenue: ${df['revenue'].sum():,.2f}")
print(f"Profit:  ${df['profit'].sum():,.2f}")
print(f"Units:   {df['quantity'].sum():,}")

print("\nRevenue by region")
print(df.groupby("region")["revenue"].sum().sort_values(ascending=False))

print("\nRevenue by product")
print(df.groupby("product")["revenue"].sum().sort_values(ascending=False))

print("\nMonthly revenue")
print(df.groupby("month")["revenue"].sum())
