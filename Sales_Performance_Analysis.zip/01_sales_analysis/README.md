# Sales Performance Analysis

## Goal
Analyze a small sample sales dataset to understand revenue, profit, units sold, product performance, and regional performance.

## Files
- `sales_data.csv` — synthetic practice data, not real company data.
- `sales_analysis.sql` — example SQL aggregation queries.
- `analyze_sales.py` — Python/Pandas summary analysis.

## How to run
1. Install Python and pandas: `pip install pandas`
2. Open a terminal in this folder.
3. Run: `python analyze_sales.py`
4. Import `sales_data.csv` into Power BI or Excel to build visuals.

## Suggested dashboard visuals
- KPI cards: Total Revenue, Total Profit, Units Sold
- Bar chart: Revenue by Product
- Column chart: Revenue by Region
- Line chart: Monthly Revenue
- Slicers: Region, Category, Order Date

## Questions to answer
1. Which region has the highest revenue?
2. Which product generates the most revenue?
3. Which month has the highest revenue?
4. Which category contributes the most profit?

## Important
This is a starter project using synthetic sample data. Verify the results yourself, add screenshots, and describe only work you have actually completed before listing it as a finished portfolio project.
