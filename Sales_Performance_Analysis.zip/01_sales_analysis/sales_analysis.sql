-- Sales Analysis Starter Queries (SQLite / MySQL with minor date-function changes)
SELECT region, SUM(revenue) AS total_revenue, SUM(profit) AS total_profit
FROM sales_data
GROUP BY region
ORDER BY total_revenue DESC;

SELECT product, SUM(quantity) AS units_sold, SUM(revenue) AS total_revenue
FROM sales_data
GROUP BY product
ORDER BY total_revenue DESC;

-- Monthly trend (MySQL)
SELECT DATE_FORMAT(order_date, '%Y-%m') AS sales_month,
       SUM(revenue) AS total_revenue,
       SUM(profit) AS total_profit
FROM sales_data
GROUP BY DATE_FORMAT(order_date, '%Y-%m')
ORDER BY sales_month;
