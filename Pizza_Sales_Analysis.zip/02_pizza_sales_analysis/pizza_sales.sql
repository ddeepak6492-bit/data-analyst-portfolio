-- Revenue by pizza
SELECT pizza_name, SUM(quantity) AS pizzas_sold,
       SUM(sales_amount) AS revenue
FROM pizza_sales
GROUP BY pizza_name
ORDER BY revenue DESC;

-- Revenue by size
SELECT size, SUM(sales_amount) AS revenue
FROM pizza_sales
GROUP BY size
ORDER BY revenue DESC;

-- Sales by category
SELECT category, SUM(quantity) AS quantity_sold,
       SUM(sales_amount) AS revenue
FROM pizza_sales
GROUP BY category
ORDER BY revenue DESC;
