# Pizza Sales Analysis

## Goal
Practice analyzing orders, pizza categories, sizes, quantity sold, and sales revenue.

## Files
- `pizza_sales.csv` — synthetic practice data.
- `pizza_sales.sql` — starter SQL questions.

## How to use
Import the CSV into Excel, Power BI, or a SQL database. In Power BI, create measures for Total Sales and Total Pizzas Sold.

## Suggested visuals
- KPI cards: Total Sales, Pizzas Sold, Number of Orders
- Bar chart: Revenue by Pizza Name
- Donut chart: Sales by Category
- Column chart: Revenue by Size
- Date slicer: Order Date

## Portfolio checklist
- [ ] Validate totals and data types
- [ ] Write 3–5 findings in your own words
- [ ] Build and save a dashboard screenshot
- [ ] Add the screenshot and completed project files to GitHub

This dataset is synthetic and for practice only. Do not present its results as real business findings.
