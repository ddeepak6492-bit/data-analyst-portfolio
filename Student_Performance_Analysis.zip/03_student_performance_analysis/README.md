# Student Performance Analysis

## Goal
Explore sample assessment scores and attendance to practice summary statistics and simple performance grouping.

## Files
- `student_performance.csv` — synthetic sample student data.
- `student_analysis.py` — Python/Pandas summaries.

## Run
1. Install pandas: `pip install pandas`
2. Run `python student_analysis.py` from this folder.

## Questions to investigate
1. Which subject has the highest average score?
2. Is attendance associated with score patterns in this small sample?
3. How many students fall into each performance band?

## Ethics note
This is entirely synthetic practice data. For real student data, remove direct identifiers and obtain authorization before sharing. Avoid making consequential judgments from this small example.
