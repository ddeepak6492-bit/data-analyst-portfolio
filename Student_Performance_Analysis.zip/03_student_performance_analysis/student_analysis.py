import pandas as pd

df = pd.read_csv("student_performance.csv")

subjects = ["math_score", "science_score", "english_score"]
print("Average score by subject:")
print(df[subjects].mean().round(1))

print("\nStudents ordered by average score:")
print(df[["student_name", "average_score", "attendance_percent"]]
      .sort_values("average_score", ascending=False).to_string(index=False))

print("\nAverage score by performance band:")
print(df.groupby("performance_band", observed=False)["average_score"].mean().round(1))
